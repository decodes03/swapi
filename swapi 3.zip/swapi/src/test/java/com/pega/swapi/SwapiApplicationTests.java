package com.pega.swapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
