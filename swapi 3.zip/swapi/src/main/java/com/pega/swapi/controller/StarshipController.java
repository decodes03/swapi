package com.pega.swapi.controller;

import com.pega.swapi.service.StarshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StarshipController {

    @Autowired
    private StarshipService starshipService;

    @GetMapping("/starships")
    public String getStarships(Model model) {
        model.addAttribute("starships", starshipService.getAllStarships());
        return "starships";
    }
}
