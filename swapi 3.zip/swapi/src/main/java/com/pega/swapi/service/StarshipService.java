package com.pega.swapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class StarshipService {

    private final String BASE_URL = "https://swapi.dev/api/starships/";

    public Map getAllStarships() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(BASE_URL, Map.class);
    }
}

