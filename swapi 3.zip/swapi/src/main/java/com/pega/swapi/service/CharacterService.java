package com.pega.swapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class CharacterService {

    private final String BASE_URL = "https://swapi.dev/api/people/";

    public Map getAllCharacters() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(BASE_URL, Map.class);
    }

    public Map searchCharacterByName(String name) {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(BASE_URL + "?search=" + name, Map.class);
    }
}


//
//public class CharacterService {
//}
