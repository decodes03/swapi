package com.pega.swapi.model;

import lombok.Data;

@Data
public class Character {
    private String name;
    private String height;
    private String mass;
    private String hairColor;
    private String skinColor;
    private String eyeColor;
    private String birthYear;
    private String gender;
}
