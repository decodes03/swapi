package com.pega.swapi.controller;

import com.pega.swapi.service.FilmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FilmController {

    @Autowired
    private FilmService filmService;

    @GetMapping("/films")
    public String getFilms(Model model) {
        model.addAttribute("films", filmService.getAllFilms());
        return "films";
    }
}
