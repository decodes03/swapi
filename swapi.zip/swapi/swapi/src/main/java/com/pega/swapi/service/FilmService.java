package com.pega.swapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class FilmService {

    private final String BASE_URL = "https://swapi.dev/api/films/";

    public Map<String, Object> getAllFilms() {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> films = restTemplate.getForObject(BASE_URL, Map.class);
        addImageUrls(films);
        return films;
    }

    public Map<String, Object> searchFilmByTitle(String title) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> films = restTemplate.getForObject(BASE_URL + "?search=" + title, Map.class);
        addImageUrls(films);
        return films;
    }

    private void addImageUrls(Map<String, Object> films) {
        List<Map<String, Object>> results = (List<Map<String, Object>>) films.get("results");
        for (Map<String, Object> film : results) {
            String title = (String) film.get("title");
            film.put("imageUrl", getImageUrlForFilm(title));
        }
    }

    private String getImageUrlForFilm(String title) {
        switch (title) {
            case "A New Hope":
                return "https://starwars-visualguide.com/assets/img/films/1.jpg";
            case "The Empire Strikes Back":
                return "https://starwars-visualguide.com/assets/img/films/2.jpg";
            case "Return of the Jedi":
                return "https://starwars-visualguide.com/assets/img/films/3.jpg";
            default:
                return "https://starwars-visualguide.com/assets/img/placeholder.jpg";
        }
    }
}
