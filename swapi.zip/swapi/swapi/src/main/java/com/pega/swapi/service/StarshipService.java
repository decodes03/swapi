package com.pega.swapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class StarshipService {

    private final String BASE_URL = "https://swapi.dev/api/starships/";

    public Map<String, Object> getAllStarships() {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> starships = restTemplate.getForObject(BASE_URL, Map.class);
        addImageUrls(starships);
        return starships;
    }

    public Map<String, Object> searchStarshipByName(String name) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> starships = restTemplate.getForObject(BASE_URL + "?search=" + name, Map.class);
        addImageUrls(starships);
        return starships;
    }

    private void addImageUrls(Map<String, Object> starships) {
        List<Map<String, Object>> results = (List<Map<String, Object>>) starships.get("results");
        for (Map<String, Object> starship : results) {
            String name = (String) starship.get("name");
            starship.put("imageUrl", getImageUrlForStarship(name));
        }
    }

    private String getImageUrlForStarship(String name) {
        switch (name) {
            case "X-wing":
                return "https://starwars-visualguide.com/assets/img/starships/12.jpg";
            case "TIE Fighter":
                return "https://starwars-visualguide.com/assets/img/starships/13.jpg";
            default:
                return "https://starwars-visualguide.com/assets/img/placeholder.jpg";
        }
    }
}
