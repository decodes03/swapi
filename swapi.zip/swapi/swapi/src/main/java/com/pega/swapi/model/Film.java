package com.pega.swapi.model;

import lombok.Data;

@Data
public class Film {
    private String title;
    private String episodeId;
    private String openingCrawl;
    private String director;
    private String producer;
    private String releaseDate;
}
